from typing import Any, Dict, List, Optional, Tuple, Union
import requests
from .exceptions import ZohoAPIError
from .auth import AuthClient

class ZohoHTTPClient:
    def __init__(self, auth: AuthClient):
        self.auth = auth

    def _request(
        self,
        method: str,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        url = f"{self.auth.base_url}/{endpoint}"
        auth_headers = self.auth.get_auth_headers()

        request_headers = (headers or {}).copy()
        request_headers.update(auth_headers)

        print(url)
        print(request_headers)
        response = requests.request(
            method=method,
            url=url,
            headers=request_headers,
            **kwargs
        )

        if not response.ok:
            raise ZohoAPIError(response.status_code, response.text)
        
        return response.json()
    
    def get(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Union[Dict[str, Any], List[Tuple[str, Any]]]] = None
    ) -> Dict[str, Any]:
        return self._request(
            "GET", 
            endpoint=endpoint, 
            headers=headers, 
            params=params
        )
    
    def post(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Union[Dict[str, Any], List[Tuple[str, Any]]]] = None,
        data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        return self._request(
            method="POST",
            endpoint=endpoint,
            headers=headers,
            params=params,
            json=data or {}
        )
    
    def put(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Union[Dict[str, Any], List[Tuple[str, Any]]]] = None,
        data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        return self._request(
            method="PUT",
            endpoint=endpoint,
            headers=headers,
            params=params,
            json=data or {}
        )
    
    def delete(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Union[Dict[str, Any], List[Tuple[str, Any]]]] = None
    ) -> Dict[str, Any]:
        return self._request(
            method="DELETE",
            endpoint=endpoint,
            headers=headers,
            params=params
        )
