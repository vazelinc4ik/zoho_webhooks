from .auth import AuthClient, Location
from .http import ZohoHTTPClient
from .entities import *

class ZohoApi:
    def __init__(self, access_token: str, location: Location):
        auth = AuthClient(access_token, location)
        client = ZohoHTTPClient(auth)

        self.contacts_client = ContactsClient(client)
        self.organizations_client = OrganizationsClient(client)
        self.sales_orders_client = SalesOrdersClient(client)
        self.items_client = ItemsClient(client)