from typing import Any, Dict, Literal
from datetime import datetime


Location = Literal['us', 'eu', 'in', 'au', 'jp', 'ca', 'cn', 'sa']

class AuthClient:
    LOCATION_URLS = {
        'us': 'https://www.zohoapis.com',
        'eu': 'https://www.zohoapis.eu',
        'in': 'https://www.zohoapis.in',
        'au': 'https://www.zohoapis.com.au',
        'jp': 'https://www.zohoapis.jp',
        'ca': 'https://www.zohoapis.ca',
        'cn': 'https://www.zohoapis.com.cn',
        'sa': 'https://www.zohoapis.sa',
    }

    def __init__(
        self,
        access_token: str,
        location: Location
    ):
        self.access_token = access_token
        self.location = location.lower()

    @property
    def base_url(self) -> str:
        """Returns the base API URL for the specified location."""
        if self.location not in self.LOCATION_URLS:
            raise ValueError(f"Unsupported location: {self.location}. "
                           f"Supported locations are: {list(self.LOCATION_URLS.keys())}")
        
        return f"{self.LOCATION_URLS[self.location]}/inventory"
    
    def get_auth_headers(self) -> Dict[str, str]:
        return {
            'Authorization': f"Zoho-oauthtoken {self.access_token}"
        }
    
