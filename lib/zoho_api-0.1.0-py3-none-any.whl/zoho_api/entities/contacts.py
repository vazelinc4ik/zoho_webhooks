from typing import Any, Dict, Optional
from ..http import ZohoHTTPClient

class ContactsClient:
    def __init__(self, client: ZohoHTTPClient):
        self._client = client
        self._base_path = "v1/contacts"

    def create_contact(
        self,
        **kwargs: Any
    ) -> Dict[str, Any]:
        headers = {
            "content-type": "application/json"
        }
        return self._client.post(self._base_path, headers=headers, data=kwargs)
    
    def list_contacts(
        self,
        email: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        params = {}
        if email:
            params['email'] = email
        return self._client.get(self._base_path, params=params)
    
