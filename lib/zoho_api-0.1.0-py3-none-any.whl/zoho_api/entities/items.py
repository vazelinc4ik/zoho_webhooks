from typing import Any, Dict
from ..http import ZohoHTTPClient

class ItemsClient:
    def __init__(self, client: ZohoHTTPClient):
        self._client = client
        self._base_path = "v1/items"

    async def list_items(self, **kwargs) -> Dict[str, Any]:
        return await self._client.get(self._base_path)