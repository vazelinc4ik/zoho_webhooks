from typing import Any, Dict
from ..http import ZohoHTTPClient

class SalesOrdersClient:
    def __init__(self, client: ZohoHTTPClient):
        self._client = client
        self._base_path = 'v1/salesorders'

    
    def create_sales_order(
        self, 
        ignore_auto_number_generation: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        params = {
            'ignore_auto_number_generation': ignore_auto_number_generation
        }
        headers = {
            "content-type": "application/json"
        }
        return self._client.post(self._base_path, headers=headers, params=params, data=kwargs)
    
    def delete_sales_order(
        self,
        sales_order_id: int
    ) -> Dict[str, Any]:
        endpoint = f"{self._base_path}/{sales_order_id}"
        return self._client.delete(endpoint)
        
    def confirm_sales_order(
        self,
        sales_order_id: int
    ) -> Dict[str, Any]:
        endpoint = f"{self._base_path}/{sales_order_id}/status/confirmed"
        return self._client.post(endpoint)