from typing import Any, Dict
from ..http import ZohoHTTPClient

class OrganizationsClient:
    def __init__(self, client: ZohoHTTPClient):
        self._client = client
        self._base_path = 'v1/organizations'

    async def list_organizations(self, **kwargs: Any) -> Dict[str, Any]:
        return await self._client.get(self._base_path)
