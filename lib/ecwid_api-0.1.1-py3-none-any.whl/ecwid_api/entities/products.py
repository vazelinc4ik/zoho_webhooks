
from typing import Any, Dict


from ..http import EcwidHTTPClient


class ProductsClient:
    def __init__(self, client: EcwidHTTPClient):
        self._client = client
        self._base_path = "/products"

    def search_products(
        self,
        **kwargs: Any
    ) -> Dict[str, Any]:
        endpoint = self._base_path
        return self._client.get(endpoint, params=kwargs)
    
    def get_product(
        self,
        product_id: str,
        **kwargs: Any
    ) -> Dict[str, Any]:
        endpoint = f"{self._base_path}/{product_id}"
        return self._client.get(endpoint, params=kwargs)
    
    def update_product(
        self,
        product_id: str,
        data: Dict[str, Any],
        **kwargs
    ) -> Dict[str, Any]:
        endpoint = f"{self._base_path}/{product_id}"
        return self._client.put(endpoint, data=data)
    
    def adjust_product_stock(
        self,
        product_id: str,
        quantity: int
    ) -> Dict[str, Any]:
        endpoint = f"{self._base_path}/{product_id}/inventory"
        return self._client.put(endpoint, data={"quantityDelta": quantity})
    
