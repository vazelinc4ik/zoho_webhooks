
from typing import Any, Dict

from ..http import EcwidHTTPClient


class OrdersClient:
    def __init__(self, client: EcwidHTTPClient):
        self._client = client
        self._base_path = "/orders"

    def get_order(
        self,
        order_id: str,
        **kwargs: Any
    ) -> Dict[str, Any]:
        endpoint = f"{self._base_path}/{order_id}"
        return self._client.get(endpoint, params=kwargs)