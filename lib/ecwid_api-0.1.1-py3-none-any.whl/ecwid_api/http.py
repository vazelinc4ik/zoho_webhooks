from typing import Any, Dict, List, Optional, Tuple, Union
from .auth import EcwidAuth

import httpx

class EcwidHTTPClient:
    def __init__(self, auth: EcwidAuth):
        self.auth = auth
        self.timeout = httpx.Timeout(10.0)

    async def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        url = self.auth.base_url + endpoint
        merged_headers = self.auth.get_auth_headers().copy()
        if headers:
            merged_headers.update(headers)

        async with httpx.AsyncClient() as client:
            response = await client.request(
                method=method,
                url=url,
                params=params,
                data=data,
                json=json,
                headers=merged_headers,
                timeout=self.timeout,
            )
            
        response.raise_for_status()
        
        return response.json()
    
    async def get(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Union[Dict[str, Any], List[Tuple[str, Any]]]] = None
    ) -> Dict[str, Any]:
        return await self._request(
            "GET", 
            endpoint=endpoint, 
            headers=headers, 
            params=params
        )
    
    async def post(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Union[Dict[str, Any], List[Tuple[str, Any]]]] = None,
        data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        return await self._request(
            method="POST",
            endpoint=endpoint,
            headers=headers,
            params=params,
            json=data or {}
        )
    
    async def put(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Union[Dict[str, Any], List[Tuple[str, Any]]]] = None,
        data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        return await self._request(
            method="PUT",
            endpoint=endpoint,
            headers=headers,
            params=params,
            json=data or {}
        )
    
    async def delete(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Union[Dict[str, Any], List[Tuple[str, Any]]]] = None
    ) -> Dict[str, Any]:
        return await self._request(
            method="DELETE",
            endpoint=endpoint,
            headers=headers,
            params=params
        )
