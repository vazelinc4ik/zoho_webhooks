

class EcwidAuth:
    def __init__(self, store_id: str, secret_token: str):
        self.store_id = store_id
        self.secret_token = secret_token

    @property
    def base_url(self) -> str:
        return f"https://app.ecwid.com/api/v3/{self.store_id}"
    
    def get_auth_headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.secret_token}"
        }