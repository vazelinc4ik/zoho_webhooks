from .auth import EcwidAuth
from .http import EcwidHTTPClient
from .entities import *

class EcwidApi:
    def __init__(self, store_id: str, secret_token: str):
        auth = EcwidAuth(store_id, secret_token)
        client = EcwidHTTPClient(auth)

        self.products_client = ProductsClient(client)
        self.orders_client = OrdersClient(client)